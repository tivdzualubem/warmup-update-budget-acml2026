# ACML publication expansion — one command for all four datasets

## Single full-run command

Extract `ACML_ALL_DATASETS_ONE_COMMAND.zip`, open a terminal in the extracted
`ACML_ALL_DATASETS_ONE_COMMAND` directory, then run:

```bash
python -u run_all_datasets.py
```

The master command runs **AG News → DBPedia → WNUT-17 → CIFAR-10**, in that order,
one dataset at a time, using all **five** specified experiment seeds. It detects up
to two GPUs (or specify `--gpus 0 1` explicitly). **It does not use the reduced
Kaggle pilot data or archived calibration thresholds.** The scientific runner
source and hyperparameter manifests are frozen at commit
`bfcbc0bae87d6969fcd4d416cdc457de52c92048`.

## Important preflight checks (recommended before multi-day training)

```bash
python -u run_all_datasets.py --verify-only
python -u run_all_datasets.py --dry-run
python -u run_all_datasets.py --preflight-only
```

- **Verify** checks every source file against `SHA256SUMS.txt` and confirms the
  four datasets have identical original scientific source files.
- **Dry run** enumerates all four experiment designs with no GPU/training.
- **Preflight** verifies CUDA GPU memory, >=15 GiB free disk, package versions,
  scientific unit tests, and accessibility of all pinned Hugging Face models and
  datasets *before* the multi-day study begins.
- Realistic capacity: heavy scratch training (AG News and DBPedia, medium-4 and
  large-6, 30 epochs) and pretrained training (3 epochs). **A complete matrix
  is likely to require significant GPU time; it has not been run end to end.**

### Environment

Recommend **Python 3.12** with GPU-enabled compatible PyTorch and torchvision.
Versions checked against the Kaggle integration environment:

```bash
python -m pip install 'datasets==5.0.0' 'transformers==5.17.0' \
  'Pillow==12.3.0' 'scikit-learn==1.9.1' 'scipy==1.18.1' \
  'setuptools_scm==7.1.0'
python -m pip install --no-build-isolation 'seqeval==1.2.2'
```

Install PyTorch/torchvision according to your CUDA driver and accelerator.
PyTorch and NVIDIA drivers must be correctly installed beforehand. Do not
upgrade dependencies mid-study. Internet access to the Hugging Face Hub is
required on first use. A HF_TOKEN can help avoid rate limiting.

## Why the four datasets are isolated

Each dataset lives in its **own** folder under `datasets/`, so the
`publication_expansion/results/scratch/loso_thresholds.json` and
`publication_expansion/results/pretrained/loso_thresholds.json` filenames
cannot overwrite another dataset's calibration. Each dataset runs all phases
in the correct dependency order: full safe controls → independent held-out
calibration → nonguarded/guarded controls → severity → matched-anchor audit.

## Expected outputs

- `datasets/AG_News/publication_expansion/results/scratch/ag_news/` (two models)
- `datasets/AG_News/publication_expansion/results/pretrained/ag_news/`
- `datasets/AG_News/publication_expansion/results/pretrained_severity/ag_news/`
- `datasets/DBPedia/publication_expansion/results/scratch/dbpedia_14/` (two models)
- `datasets/DBPedia/publication_expansion/results/pretrained/dbpedia_14/`
- `datasets/DBPedia/publication_expansion/results/pretrained_severity/dbpedia_14/`
- `datasets/WNUT_17/publication_expansion/results/pretrained/wnut_17/`
- `datasets/WNUT_17/publication_expansion/results/pretrained_severity/wnut_17/`
- `datasets/CIFAR_10/publication_expansion/results/pretrained/cifar10/`
- `datasets/CIFAR_10/publication_expansion/results/pretrained_severity/cifar10/`

A full run is **240 scientific jobs plus 20 severity diagnostic jobs**.
`run_logs/<dataset>.log` streams each dataset, and original per-job logs,
`result.json`, `history.json`, `trace.json`, and phase audits are in the
respective dataset `publication_expansion/results/` directory. High-level
run status lives in `run_status/run_all_status.json`.

## If something fails or is interrupted

**Do not delete the output directories.** Fix the reported issue, then rerun
the exact same one-line command:

```bash
python -u run_all_datasets.py
```

Original runners skip completed jobs and save epoch-boundary resume checkpoints
for unfinished training jobs. The master script independently checks the
presence of all expected complete per-seed results and calibration records
at the end of each dataset. It stops visibly on errors; it does not silently
mark incomplete runs successful. Download or back up results and checkpoints
periodically on long runs. Avoid changing the experiment code or configuration
between interrupted runs.

Optional: `python -u run_all_datasets.py --only CIFAR_10` retries a dataset
independently. `--gpus 0 1` chooses specific GPU IDs, and `--num-workers 0`
may be useful for worker-process troubleshooting.

### Scientific limitations and numerical reproducibility

This master wrapper was statically checked and its **no-training full-matrix
command** was exercised. The actual full 260-job multi-GPU study has **not**
been executed, so no one can promise it will never fail on different hardware.
The earlier reduced Kaggle 48-job suite passed after one CIFAR fail-fast
clipped-gradient fingerprint mismatch was resolved on retry. Exact GPU gradient
fingerprints may vary across hardware/kernel execution; matched-anchor audits
are intentionally strict and must NOT be bypassed. A repeat mismatch should
be investigated rather than relabeled as a pass. This master launcher uses
`CUBLAS_WORKSPACE_CONFIG=:4096:8` consistently for subprocesses, but this
alone does not guarantee bitwise determinism for all kernels.

All original frozen scientific files and seed/epoch settings remain unchanged.
