# WNUT-17 — full publication experiment package

This package follows the original one-script AG News/DBPedia handoff design:
**one dataset, one runnable entry script, fixed seed list, frozen manifests and
explicit output paths**. It contains the original frozen scientific runner source.

## Run command (one GPU)

```bash
python -u run_full_wnut17.py
```

Two GPUs, if available:

```bash
python -u run_full_wnut17.py --gpus 0 1
```

To inspect all  job commands without training:

```bash
python -u run_full_wnut17.py --dry-run
```

To resume after an interrupted/failed phase, run the **same command** again;
original full runners skip completed jobs and resume checkpoints at epoch boundaries.
To resume a single phase after repairing a failure:
`python -u run_full_wnut17.py --phase pretrained-safe --gpus 0 1 --skip-tests`
(Replace `pretrained-safe` with the desired phase.)

## Hardware and dependencies

Use an isolated Python 3.12 environment with GPU-enabled PyTorch appropriate
for the GPU, transformers 5.17.0, datasets 5.0.0, scikit-learn 1.9.1,
seqeval 1.2.2, numpy, scipy, Pillow and torchvision. Run commands from the
unpacked package root. Internet access to Hugging Face is needed to populate
pinned source/model caches initially. Source commits are frozen in
`publication_expansion/configs/`; changing them invalidates comparisons.

```bash
python -m pip install 'datasets==5.0.0' 'transformers==5.17.0' 'Pillow==12.3.0' 'scikit-learn==1.9.1' 'scipy==1.18.1' 'setuptools_scm==7.1.0'
python -m pip install --no-build-isolation 'seqeval==1.2.2'
python -m unittest discover -s publication_expansion/tests -t . -q
```

Do **not** run the full matrix on Kaggle's small shared accelerator budget.
Unlike the reduced 48-job functional validation, these are substantial
multi-hour/multi-day experiments. Before committing to a complete run, plan
GPU capacity and storage; the per-job heartbeat announces a running process
but cannot promise a completion time. A diagnostic stop is a valid experimental
outcome and does not automatically mean the job crashed.

## Frozen experimental design

- Datasets: **WNUT-17** only; untouched full training data.
- Experiment seeds: 42, 123, 456, 789, 2026; fixed split seed 42.
- Scratch models, if applicable: medium-4, large-6; **30 epochs**, Adam.
- Pretrained model: **distilbert/distilbert-base-uncased**, **3 epochs**, AdamW.
- Warmup scheduler comparisons; guarded rescue/failfast; single bad first step.
- Primary guard threshold: leave-one-seed-out on the other four safe seeds,
  first 100 steps, multiplier κ=10. Calibration is recomputed from **full**
  runs, not copied from Kaggle pilot results.
- First-transition mismatch severity: 7 LR multipliers plus natural mismatch.
- Fixed execution details: `publication_expansion/configs/hyperparameters_v1.json`.

## Run sequence

1. `pretrained-safe`
2. `pretrained-thresholds`
3. `pretrained-nonguarded`
4. `pretrained-rescue`
5. `pretrained-diagnostic`
6. `pretrained-severity`
7. `pretrained-anchor-audit`

The entry script executes the phases in sequence and stops when a check fails;
there is **no need to run individual scripts manually**. Each phase outputs
raw per-seed `result.json`, `history.json`, `trace.json`, and
`job_manifest.json` under the appropriate result folder. The original
runners keep resume checkpoints during interrupted jobs; completed runs
remove their temporary checkpoint files.

## Expected output folders

- `publication_expansion/results/pretrained/wnut_17/seed{seed}/{condition}/`
- `publication_expansion/results/pretrained_severity/wnut_17/seed{seed}/`
- `publication_expansion/results/pretrained/loso_thresholds.json`

Phase logs:
`publication_expansion/results/full_run_logs/`

Manifest: `full_run_manifest.json` in this package.

## Strict evidence separation

The complete integration test previously passed **48/48 jobs**, but its
small-data single-seed metrics are only functional validation and are
**not** included as publication results. Neither this package nor its
validation claims that full scientific training is complete.

Original frozen scientific source commit:
`bfcbc0bae87d6969fcd4d416cdc457de52c92048`.
Original source bundle SHA-256:
`34392d6b2655b0c9152b6c6a2363e3e91dcd7a459e8cda278359148dbb13b19e`.

**Important:** The new one-script entry point only orchestrates the original
frozen `publication_expansion` scientific implementations; it does not change
the training algorithms, schedulers, seed policy, guard, or datasets.
