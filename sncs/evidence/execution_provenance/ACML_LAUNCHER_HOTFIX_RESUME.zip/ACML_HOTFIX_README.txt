ACML FULL-RUN HOTFIX - 2026-10-11

WHY
AG News log confirms 40 finished scratch jobs (20 safe and 20 unguarded),
then run_full_agnews.py crashes before scratch-guarded because its
job builder tries to resolve a DBpedia LOSO threshold from an AG-only
manifest. Earlier attempts also hit a queue tuple/dictionary bug.

ON PROFESSOR'S EXISTING EXTRACTED DIRECTORY
1. Download the hotfix ZIP; copy apply_acml_fullrun_hotfix.py into the
   existing ACML_ALL_DATASETS_ONE_COMMAND/ folder, beside run_all_datasets.py.
2. In terminal, change directory into that EXISTING folder; do NOT
   extract/recreate the original full source package in a new folder.
3. Apply (no training):
      python3 apply_acml_fullrun_hotfix.py
4. On seeing [HOTFIX] PASS, resume the original master command:
      python3 -u run_all_datasets.py

WHAT CHANGES
Four Python dataset entry wrappers + their corresponding checksum
manifest entries. Does NOT modify frozen scientific modules,
calibration results, checkpoints, job results, or collected traces.
Backups of each wrapper/checksum are created automatically.

VALIDATION OF PATCH
- Original master ZIP extracted and hotfix applied
- Root --verify-only succeeded (checksum verification)
- Root --dry-run succeeded (four datasets, no training)
- Focused non-GPU job-building tests succeeded: guarded scratch, calibrated
  pretrained rescue and diagnostics, all four datasets and five seeds
- Idempotent application succeeded

CAUTION
These checks verify the observed orchestration failures. They cannot
prove a long full scientific GPU run will encounter no future issues.
