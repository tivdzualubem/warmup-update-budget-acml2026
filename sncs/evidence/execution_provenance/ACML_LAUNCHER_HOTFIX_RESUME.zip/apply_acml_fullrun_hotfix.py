#!/usr/bin/env python3
"""In-place ACML full-run launcher hotfix, 2026-10-11.

Run from inside the EXISTING extracted ACML_ALL_DATASETS_ONE_COMMAND directory
(e.g. `python3 apply_acml_fullrun_hotfix.py`). Does not delete, move or edit
any experiment results. Only patches four dataset launchers and refreshes their
launcher checksums; frozen scientific implementations remain unchanged.
"""
from __future__ import annotations

import hashlib
import json
import os
import py_compile
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PACKAGES = {
    'AG_News': 'run_full_agnews.py',
    'DBPedia': 'run_full_dbpedia.py',
    'WNUT_17': 'run_full_wnut17.py',
    'CIFAR_10': 'run_full_cifar10.py',
}


def atomic_write(path: Path, data: bytes) -> None:
    staging = path.with_name(path.name + '.hotfix_tmp')
    staging.write_bytes(data)
    os.replace(staging, path)


def patch_script(data: str) -> str:
    anchor = "LOG_ROOT = Path('publication_expansion/results/full_run_logs')\n"
    insertion = (
        "\n# Hotfix: scope the FROZEN matrix enumerators to this dataset before\n"
        "# guard-threshold lookup. Filtering AFTER build_jobs() is too late.\n"
        "scratch.DATASETS = (DATASET,)\n"
        "pre.DATASETS = (DATASET,)\n"
    )
    if 'scratch.DATASETS = (DATASET,)' not in data:
        if data.count(anchor) != 1:
            raise RuntimeError('Cannot locate exact dataset-scoping insertion site')
        data = data.replace(anchor, anchor + insertion, 1)

    # Build_jobs returns (job_dict, planned_command) tuples. The worker
    # expects a job_dict, so queue only the dict. Correct an unpatched copy;
    # tolerate the professor's previously modified copy if already fixed.
    if 'job_queue.put(job)' in data:
        data = data.replace('job_queue.put(job)',
                            'job_queue.put(job[0] if isinstance(job, tuple) else job)', 1)
    elif ('job_queue.put(job[0])' not in data and
          'job_queue.put(job[0] if isinstance(job, tuple) else job)' not in data):
        raise RuntimeError('Cannot establish that tuple/dict queue bug is fixed')
    return data


def main():
    if not (ROOT / 'run_all_datasets.py').is_file():
        raise SystemExit('Place this script inside the existing extracted ACML_ALL_DATASETS_ONE_COMMAND folder, then run it there. No experiment results should be moved.')

    print('[HOTFIX] Preparing all four dataset launchers, preserving results', flush=True)
    plans = []
    for label, filename in PACKAGES.items():
        directory = ROOT / 'datasets' / label
        runner = directory / filename
        sums = directory / 'SHA256SUMS.txt'
        if not (runner.is_file() and sums.is_file()):
            raise RuntimeError(f'Missing package files: {label}')
        original = runner.read_bytes()
        updated = patch_script(original.decode('utf-8')).encode('utf-8')
        # Preserve all original checksum entries except the changed launcher.
        lines = sums.read_text(encoding='utf-8').splitlines()
        hits = [i for i, line in enumerate(lines) if line.endswith('  ' + filename)]
        if len(hits) != 1:
            raise RuntimeError(f'Missing/duplicate launcher checksum: {label}')
        index = hits[0]
        lines[index] = hashlib.sha256(updated).hexdigest() + '  ' + filename
        new_sums = ('\n'.join(lines) + '\n').encode('utf-8')
        plans.append((label, runner, original, updated, sums, sums.read_bytes(), new_sums))

    for label, runner, old, updated, sums, old_sums, new_sums in plans:
        # Backups are not part of the master checksum manifest.
        backup = runner.with_suffix('.py.before_hotfix.bak')
        if not backup.exists():
            backup.write_bytes(old)
        sums_backup = sums.with_suffix('.txt.before_hotfix.bak')
        if not sums_backup.exists():
            sums_backup.write_bytes(old_sums)
        atomic_write(runner, updated)
        atomic_write(sums, new_sums)
        py_compile.compile(str(runner), doraise=True)
        print(f'[HOTFIX] {label}: corrected queue and dataset-scoped thresholds', flush=True)

    # This checks the exact SHA-256 list of every preserved frozen source file.
    for command in (
        [sys.executable, '-u', 'run_all_datasets.py', '--verify-only'],
        [sys.executable, '-u', 'run_all_datasets.py', '--dry-run'],
    ):
        print('[HOTFIX] Check:', ' '.join(command[2:]), flush=True)
        subprocess.run(command, cwd=ROOT, check=True, stdout=subprocess.DEVNULL)

    print('[HOTFIX] PASS: all four launchers patched; source integrity + dry-run verified.', flush=True)
    print('[HOTFIX] EXISTING 40 AG News job results and calibration remain untouched.', flush=True)
    print('[NEXT] From this same folder: python -u run_all_datasets.py', flush=True)


if __name__ == '__main__':
    main()
