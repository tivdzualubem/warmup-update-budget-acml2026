#!/usr/bin/env python
from pathlib import Path
import sys

REPO_ROOT = Path(__file__).resolve().parents[2]

if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from publication_expansion.src.scratch_job_runner import main


if __name__ == "__main__":
    main()
